package com.example.blog.controller;

import com.example.blog.model.Post;
import com.example.blog.model.User;
import com.example.blog.repository.PostRepository;
import com.example.blog.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/posts")
public class PostController {

    @Autowired
    private PostRepository postRepo;

    @Autowired
    private UserRepository userRepo;

    @GetMapping
    public List<Post> getAll() {
        return postRepo.findAll();
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Post post, Authentication auth) {
        var username = auth.getName();
        var user = userRepo.findByUsername(username).orElse(null);
        post.setAuthor(user);
        return ResponseEntity.ok(postRepo.save(post));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Post post, Authentication auth) {
        var existing = postRepo.findById(id).orElse(null);
        if (existing == null) return ResponseEntity.notFound().build();
        // only author or admin can update
        if (!auth.getName().equals(existing.getAuthor().getUsername()) && auth.getAuthorities().stream().noneMatch(a->a.getAuthority().equals("ROLE_ADMIN"))) {
            return ResponseEntity.status(403).body("forbidden");
        }
        existing.setTitle(post.getTitle());
        existing.setContent(post.getContent());
        postRepo.save(existing);
        return ResponseEntity.ok(existing);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id, Authentication auth) {
        var existing = postRepo.findById(id).orElse(null);
        if (existing == null) return ResponseEntity.notFound().build();
        if (!auth.getName().equals(existing.getAuthor().getUsername()) && auth.getAuthorities().stream().noneMatch(a->a.getAuthority().equals("ROLE_ADMIN"))) {
            return ResponseEntity.status(403).body("forbidden");
        }
        postRepo.deleteById(id);
        return ResponseEntity.ok("deleted");
    }
}

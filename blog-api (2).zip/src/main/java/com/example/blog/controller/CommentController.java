package com.example.blog.controller;

import com.example.blog.model.Comment;
import com.example.blog.model.Post;
import com.example.blog.repository.CommentRepository;
import com.example.blog.repository.PostRepository;
import com.example.blog.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
public class CommentController {

    @Autowired
    private CommentRepository commentRepo;

    @Autowired
    private PostRepository postRepo;

    @Autowired
    private UserRepository userRepo;

    @PostMapping
    public ResponseEntity<?> create(@RequestParam Long postId, @RequestBody Comment comment, Authentication auth) {
        Post post = postRepo.findById(postId).orElse(null);
        if (post == null) return ResponseEntity.badRequest().body("post not found");
        var user = userRepo.findByUsername(auth.getName()).orElse(null);
        comment.setPost(post);
        comment.setAuthor(user);
        return ResponseEntity.ok(commentRepo.save(comment));
    }

    @GetMapping
    public List<Comment> list(@RequestParam Long postId) {
        return commentRepo.findByPostId(postId);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id, Authentication auth) {
        var existing = commentRepo.findById(id).orElse(null);
        if (existing == null) return ResponseEntity.notFound().build();
        if (!auth.getName().equals(existing.getAuthor().getUsername()) && auth.getAuthorities().stream().noneMatch(a->a.getAuthority().equals("ROLE_ADMIN"))) {
            return ResponseEntity.status(403).body("forbidden");
        }
        commentRepo.deleteById(id);
        return ResponseEntity.ok("deleted");
    }
}

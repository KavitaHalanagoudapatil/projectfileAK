Blog API (Spring Boot) - MySQL version

How to run:
1. Install Java 17+ and Maven.
2. Create a MySQL database named `blogdb` and update username/password in src/main/resources/application.properties.
3. From the project root (where pom.xml is):
   mvn spring-boot:run
4. Endpoints:
   POST /auth/register   -> register (body: {username, password})
   POST /auth/login      -> login (body: {username, password}) returns {token}
   GET  /posts
   POST /posts           -> create (Authorization: Bearer <token>, body: {title, content})
   PUT  /posts/{id}
   DELETE /posts/{id}
   GET  /comments?postId=<id>
   POST /comments?postId=<id> -> create comment (Authorization header required)

Notes:
- JWT secret is in application.properties; change for production.
- Uses Lombok: install Lombok plugin in IDE or remove Lombok annotations.

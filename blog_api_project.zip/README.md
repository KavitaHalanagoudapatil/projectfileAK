# RESTful Blog API (Flask)

Minimal RESTful Blog API that supports posts, comments, user registration and JWT authentication.

## Structure
- app.py - main Flask application and routes
- models.py - SQLAlchemy models and DB setup (uses SQLite for simplicity)
- auth.py - helpers for JWT creation and verification
- requirements.txt - Python dependencies
- tests.py - unit tests using Flask test client

## Run locally
1. Create virtualenv and install requirements:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
2. Initialize DB and run:
   ```bash
   export FLASK_APP=app.py
   flask run
   ```
3. Or run directly:
   ```bash
   python app.py
   ```

## Notes
- JWT secret is in environment variable `JWT_SECRET` (fallback provided in app for demo).
- Uses SQLite (`blog.db`) for ease of setup. For production, switch to PostgreSQL/MySQL.

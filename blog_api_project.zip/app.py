import os, json
from flask import Flask, request, jsonify, abort
from models import db, User, Post, Comment
from auth import hash_password, verify_password, create_access_token, decode_token
from functools import wraps

def create_app(test_config=None):
    app = Flask(__name__)
    db_path = os.path.join(os.path.dirname(__file__), 'blog.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)

    if test_config:
        app.config.update(test_config)

    def login_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            auth = request.headers.get('Authorization', None)
            if not auth or not auth.startswith('Bearer '):
                return jsonify({'message':'Missing token'}), 401
            token = auth.split(None,1)[1]
            payload = decode_token(token)
            if not payload:
                return jsonify({'message':'Invalid or expired token'}), 401
            request.user_id = payload.get('sub')
            return f(*args, **kwargs)
        return decorated

    @app.before_first_request
    def create_tables():
        db.create_all()

    # Auth
    @app.route('/register', methods=['POST'])
    def register():
        data = request.get_json() or {}
        username = data.get('username')
        password = data.get('password')
        email = data.get('email')
        if not username or not password:
            return jsonify({'message':'username and password required'}), 400
        if User.query.filter_by(username=username).first():
            return jsonify({'message':'username exists'}), 400
        user = User(username=username, password_hash=hash_password(password), email=email)
        db.session.add(user)
        db.session.commit()
        return jsonify({'id': user.id, 'username': user.username}), 201

    @app.route('/login', methods=['POST'])
    def login():
        data = request.get_json() or {}
        username = data.get('username')
        password = data.get('password')
        if not username or not password:
            return jsonify({'message':'username and password required'}), 400
        user = User.query.filter_by(username=username).first()
        if not user or not verify_password(password, user.password_hash):
            return jsonify({'message':'invalid credentials'}), 401
        token = create_access_token(user.id)
        return jsonify({'access_token': token})

    # Posts endpoints
    @app.route('/posts', methods=['POST'])
    @login_required
    def create_post():
        data = request.get_json() or {}
        title = data.get('title')
        content = data.get('content')
        if not title or not content:
            return jsonify({'message':'title and content required'}), 400
        post = Post(title=title, content=content, author_id=request.user_id)
        db.session.add(post)
        db.session.commit()
        return jsonify({'id': post.id, 'title': post.title}), 201

    @app.route('/posts', methods=['GET'])
    def list_posts():
        posts = Post.query.all()
        result = []
        for p in posts:
            result.append({'id':p.id,'title':p.title,'content':p.content,'author_id':p.author_id,'created_at':p.created_at.isoformat()})
        return jsonify(result)

    @app.route('/posts/<int:post_id>', methods=['GET'])
    def get_post(post_id):
        p = Post.query.get_or_404(post_id)
        return jsonify({'id':p.id,'title':p.title,'content':p.content,'author_id':p.author_id,'created_at':p.created_at.isoformat()})

    @app.route('/posts/<int:post_id>', methods=['PUT'])
    @login_required
    def update_post(post_id):
        p = Post.query.get_or_404(post_id)
        if p.author_id != request.user_id:
            return jsonify({'message':'forbidden'}), 403
        data = request.get_json() or {}
        p.title = data.get('title', p.title)
        p.content = data.get('content', p.content)
        db.session.commit()
        return jsonify({'id':p.id,'title':p.title,'content':p.content})

    @app.route('/posts/<int:post_id>', methods=['DELETE'])
    @login_required
    def delete_post(post_id):
        p = Post.query.get_or_404(post_id)
        if p.author_id != request.user_id:
            return jsonify({'message':'forbidden'}), 403
        db.session.delete(p)
        db.session.commit()
        return jsonify({'message':'deleted'})

    # Comments
    @app.route('/comments', methods=['POST'])
    @login_required
    def create_comment():
        data = request.get_json() or {}
        post_id = data.get('post_id')
        content = data.get('content')
        if not post_id or not content:
            return jsonify({'message':'post_id and content required'}), 400
        # ensure post exists
        from models import Post as PostModel
        if not PostModel.query.get(post_id):
            return jsonify({'message':'post not found'}), 404
        c = Comment(post_id=post_id, content=content, author_id=request.user_id)
        db.session.add(c)
        db.session.commit()
        return jsonify({'id': c.id, 'post_id': c.post_id}), 201

    @app.route('/comments', methods=['GET'])
    def list_comments():
        post_id = request.args.get('post_id', type=int)
        if post_id:
            comments = Comment.query.filter_by(post_id=post_id).all()
        else:
            comments = Comment.query.all()
        res = [{'id':c.id,'post_id':c.post_id,'content':c.content,'author_id':c.author_id,'created_at':c.created_at.isoformat()} for c in comments]
        return jsonify(res)

    @app.route('/comments/<int:comment_id>', methods=['GET'])
    def get_comment(comment_id):
        c = Comment.query.get_or_404(comment_id)
        return jsonify({'id':c.id,'post_id':c.post_id,'content':c.content,'author_id':c.author_id,'created_at':c.created_at.isoformat()})

    @app.route('/comments/<int:comment_id>', methods=['PUT'])
    @login_required
    def update_comment(comment_id):
        c = Comment.query.get_or_404(comment_id)
        if c.author_id != request.user_id:
            return jsonify({'message':'forbidden'}), 403
        data = request.get_json() or {}
        c.content = data.get('content', c.content)
        db.session.commit()
        return jsonify({'id':c.id,'content':c.content})

    @app.route('/comments/<int:comment_id>', methods=['DELETE'])
    @login_required
    def delete_comment(comment_id):
        c = Comment.query.get_or_404(comment_id)
        if c.author_id != request.user_id:
            return jsonify({'message':'forbidden'}), 403
        db.session.delete(c)
        db.session.commit()
        return jsonify({'message':'deleted'})

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)

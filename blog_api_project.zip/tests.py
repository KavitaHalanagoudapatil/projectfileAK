import unittest, json
from app import create_app, db
from models import User

class BlogAPITestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app({'TESTING': True, 'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:'})
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def test_register_login_and_post_lifecycle(self):
        # register
        r = self.client.post('/register', json={'username':'alice','password':'pass123'})
        self.assertEqual(r.status_code, 201)
        # login
        r = self.client.post('/login', json={'username':'alice','password':'pass123'})
        self.assertEqual(r.status_code, 200)
        token = json.loads(r.data)['access_token']
        headers = {'Authorization': f'Bearer {token}'}
        # create post
        r = self.client.post('/posts', json={'title':'Hello','content':'World'}, headers=headers)
        self.assertEqual(r.status_code, 201)
        post_id = json.loads(r.data)['id']
        # read post
        r = self.client.get(f'/posts/{post_id}')
        self.assertEqual(r.status_code, 200)
        # update post
        r = self.client.put(f'/posts/{post_id}', json={'title':'Hello2'}, headers=headers)
        self.assertEqual(r.status_code, 200)
        # delete post
        r = self.client.delete(f'/posts/{post_id}', headers=headers)
        self.assertEqual(r.status_code, 200)

if __name__ == '__main__':
    unittest.main()

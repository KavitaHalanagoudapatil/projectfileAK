import os, jwt, datetime
from passlib.hash import pbkdf2_sha256 as sha256

JWT_SECRET = os.environ.get('JWT_SECRET', 'dev-secret-for-demo-only')
JWT_ALGO = 'HS256'

def hash_password(password: str) -> str:
    return sha256.hash(password)

def verify_password(password: str, password_hash: str) -> bool:
    return sha256.verify(password, password_hash)

def create_access_token(user_id: int, expires_minutes: int = 60):
    payload = {
        'sub': user_id,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=expires_minutes),
        'iat': datetime.datetime.utcnow()
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

def decode_token(token: str):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        return payload
    except Exception as e:
        return None
